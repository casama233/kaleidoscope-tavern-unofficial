# Credits and source boundaries

Original mod: Kaleidoscope Tavern. Metadata authors: ysbbbbbb, tartaric_acid.
Original development/art team: Kaleidoscope Official Production Team.

This is a read-only source-intake package prepared from the user's uploaded
`kaleidoscopetavern-1.2.0-neoforge+mc1.21.1.jar`. Resource members were retained
byte-for-byte. `source-jar.lock.json` identifies the input and each resource.
Artwork, models, language and sounds remain subject to the upstream resource
license. The existing project license texts are reproduced in LICENSE-ASSETS
and LICENSE-CODE; extraction does not relicense any upstream content.

Three readable Java references come from the upstream 1.21.1 branch snapshot
recorded in github-source.lock.json. They are not asserted to identify the full
release build commit. The old pinned Git source is not overwritten.

Previews arrange original textures at integer nearest-neighbor scale, without
recoloring. Font files are not included. No game-runtime verification, official
publisher checksum verification, upstream endorsement or official Bedrock port
status is claimed. The complete original JAR is not redistributed in this ZIP.
