#!/usr/bin/env python3
"""Read-only audit and safe art extraction. Does not execute the mod or overwrite A16.
Usage: python tools/audit_jar.py --jar PATH --baseline PATH --output DIRECTORY
"""
from __future__ import annotations
import argparse, collections, hashlib, io, json, subprocess, zipfile
from pathlib import Path, PurePosixPath
from PIL import Image

NS = 'assets/kaleidoscope_tavern/'
DENY_EXT = {'.ttf','.otf','.ttc','.woff','.woff2','.eot'}
MISSING_LIGHTS = ['green','light_blue','light_gray','lime','magenta','orange','pink','purple','yellow']
FLOWERS = ['allium','azure_bluet','cornflower','grass','orchid','peony','pink_petals','pitcher_plant','poppy','sunflower','torchflower','tulip','wither_rose']

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def git_blob(data: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def write_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def safe_path(name: str) -> bool:
    p=PurePosixPath(name)
    return not p.is_absolute() and '..' not in p.parts and '\\' not in name and p.suffix.lower() not in DENY_EXT

def run(jar_path: Path, baseline: Path, output: Path) -> dict:
    jar_bytes=jar_path.read_bytes()
    if not zipfile.is_zipfile(jar_path):
        raise ValueError('Input is not a readable ZIP/JAR archive')
    reports=output/'reports'; reports.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(jar_path) as z, zipfile.ZipFile(baseline) as old:
        infos=z.infolist()
        if len(infos)>100000 or sum(i.file_size for i in infos)>500_000_000:
            raise ValueError('Archive exceeds inspection size limit')
        names=[i.filename for i in infos if not i.is_dir()]
        if len(names)!=len(set(names)):
            raise ValueError('Duplicate ZIP entries must be resolved first')
        crc_error=z.testzip()
        if crc_error: raise ValueError('CRC error: '+crc_error)
        inventory=[]; validation_errors=[]; extracted=[]
        for name in sorted(names):
            data=z.read(name)
            inventory.append({'path':name,'bytes':len(data),'sha256':sha(data),'git_blob_sha1':git_blob(data)})
            if not name.startswith(NS):continue
            if not safe_path(name):raise ValueError('Unsafe or excluded archive path: '+name)
            if name.endswith('.json') or name.endswith('.mcmeta'):
                try: json.loads(data)
                except Exception as e: validation_errors.append({'path':name,'error':str(e)})
            if name.endswith('.png'):
                try:
                    with Image.open(io.BytesIO(data)) as im: im.verify()
                except Exception as e: validation_errors.append({'path':name,'error':str(e)})
            p=output/'jar-resources'/name
            p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
            extracted.append(name)
        for name in ['META-INF/MANIFEST.MF','META-INF/neoforge.mods.toml','pack.mcmeta']:
            if name in names:
                p=output/'jar-metadata'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
        old_names=set(old.namelist())
        lock_path=next(n for n in old_names if n.count('/')==1 and n.endswith('/sources.lock.json'))
        old_root=lock_path.rsplit('/',1)[0]+'/'
        lock=json.loads(old.read(lock_path))
        results=[]
        for entry in lock['assets']:
            path=entry['path']
            if '/resources/' not in path:continue
            jar_name=path.split('/resources/',1)[1]
            if not jar_name.startswith('assets/'):continue
            old_name=old_root+'upstream/'+path
            if old_name not in old_names:raise ValueError('Baseline declared source is absent: '+old_name)
            b=old.read(old_name)
            row={'baseline_path':path,'jar_path':jar_name,'baseline_sha256':sha(b),'baseline_git_blob_sha1':git_blob(b)}
            if jar_name not in names:row['status']='MISSING_IN_UPLOADED_JAR'
            else:
                n=z.read(jar_name);row['jar_sha256']=sha(n);row['jar_git_blob_sha1']=git_blob(n)
                if b==n:row['status']='BYTE_IDENTICAL'
                elif jar_name.endswith('.png'):
                    with Image.open(io.BytesIO(b)) as ob,Image.open(io.BytesIO(n)) as ne:
                        b_im=ob.convert('RGBA');n_im=ne.convert('RGBA')
                        row['baseline_size']=list(b_im.size);row['jar_size']=list(n_im.size)
                        row['status']='RGBA_PIXELS_IDENTICAL' if b_im.size==n_im.size and b_im.tobytes()==n_im.tobytes() else 'PIXELS_DIFFER'
                elif jar_name.endswith(('.json','.mcmeta')):
                    try: row['status']='PARSED_JSON_IDENTICAL' if json.loads(b)==json.loads(n) else 'JSON_CONTENT_DIFFERS'
                    except Exception: row['status']='OTHER_CONTENT_DIFFERS'
                else:row['status']='OTHER_CONTENT_DIFFERS'
            results.append(row)
        # Original attribution files are copied from the existing source project, not invented.
        for name in ['LICENSE-ASSETS','LICENSE-CODE']:
            if old_root+name in old_names:(output/name).write_bytes(old.read(old_root+name))
        light_models=sorted(n for n in names if n.startswith(NS+'models/block/deco/string_lights/') and n.endswith('.json'))
        light_textures=sorted(n for n in names if n.startswith(NS+'textures/block/deco/string_lights/') and n.endswith('.png'))
        lights=[]
        for model in light_models:
            color=PurePosixPath(model).stem;data=json.loads(z.read(model));texture=NS+f'textures/block/deco/string_lights/{color}.png'
            lights.append({'color':color,'model':model,'texture':texture,'texture_exists':texture in names,'elements':len(data.get('elements',[])),'missing_in_A16':color in MISSING_LIGHTS})
        boards=[]
        for kind in ['base']+FLOWERS:
            rotation_paths=[NS+f'models/block/deco/sandwich_board/{kind}/rot_{i}.json' for i in range(16)]
            texture=NS+f'textures/block/deco/sandwich_board/{"body" if kind=="base" else kind}.png'
            blockstate=NS+f'blockstates/{kind}_sandwich_board.json';item=NS+f'models/item/{kind}_sandwich_board.json'
            board={'variant':kind,'texture':texture,'texture_exists':texture in names,'rotation_model_count':sum(p in names for p in rotation_paths),'rotation_models':rotation_paths,'blockstate':blockstate,'blockstate_exists':blockstate in names,'item_model':item,'item_model_exists':item in names}
            for p in rotation_paths:
                if p not in names:continue
                q=json.loads(z.read(p)).get('transform',{}).get('rotation')
                if q is not None and (len(q)!=4 or abs(sum(float(v)**2 for v in q)-1)>2e-6):
                    validation_errors.append({'path':p,'error':'invalid rotation quaternion'})
            boards.append(board)
        class_names=['com/github/ysbbbbbb/kaleidoscopetavern/client/model/deco/SmallChalkboardModel.class','com/github/ysbbbbbb/kaleidoscopetavern/client/model/deco/LargeChalkboardModel.class','com/github/ysbbbbbb/kaleidoscopetavern/client/render/block/ChalkboardBlockEntityRender.class']
        chalk=[]
        for kind in ['small','large']:
            texture=NS+f'textures/entity/deco/{kind}_chalkboard.png'
            with Image.open(io.BytesIO(z.read(texture))) as im:size=list(im.size)
            chalk.append({'size':kind,'texture':texture,'texture_dimensions':size,'model_class':class_names[0 if kind=='small' else 1]})
        disassemblies=[]
        for name in class_names:
            classname=name[:-6].replace('/','.')
            cp=subprocess.run(['javap','-classpath',str(jar_path),'-p','-c',classname],capture_output=True,text=True,timeout=20)
            out=reports/'javap'/f'{PurePosixPath(name).stem}.txt';out.parent.mkdir(parents=True,exist_ok=True)
            out.write_text(cp.stdout,encoding='utf-8')
            disassemblies.append({'class':name,'class_sha256':sha(z.read(name)),'javap_exit_code':cp.returncode,'report':out.relative_to(output).as_posix(),'execution_note':'javap disassembly only; the mod was not run'})
        counts=collections.Counter(n[len(NS):].split('/')[0] if '/' in n[len(NS):] else '__root__'for n in extracted)
        cmp_count=dict(collections.Counter(r['status'] for r in results))
        png_rows=[r for r in results if r['jar_path'].endswith('.png')]
        summary={
            'input':{'file':jar_path.name,'bytes':len(jar_bytes),'sha256':sha(jar_bytes),'identity':'1.2.0-neoforge+mc1.21.1','origin':'user_upload','publisher_checksum_verified':False,'jar_executed':False},
            'archive':{'entries_including_directories':len(infos),'files':len(names),'duplicate_entries':False,'crc':'PASS','extracted_namespace_asset_files':len(extracted),'category_counts':dict(counts),'png_files':sum(n.endswith('.png')for n in extracted)},
            'comparison_to_A16':{'baseline_archive':baseline.name,'baseline_pinned_commit':lock['commit'],'compared_resource_files':len(results),'statuses':cmp_count,'compared_png_files':len(png_rows),'png_statuses':dict(collections.Counter(r['status']for r in png_rows)),'whole_release_equivalence_claimed':False,'same_loader_or_game_version_claimed':False,'baseline_files_overwritten':False},
            'priority_sources':{'string_light_models':len(light_models),'string_light_textures':len(light_textures),'nine_previous_missing_models_found':all(NS+f'models/block/deco/string_lights/{c}.json'in names for c in MISSING_LIGHTS),'nine_previous_missing_textures_found':all(NS+f'textures/block/deco/string_lights/{c}.png'in names for c in MISSING_LIGHTS),'board_variants':len(boards),'board_floral_variants':len(FLOWERS),'board_rotation_models':sum('/models/block/deco/sandwich_board/'in n and PurePosixPath(n).name.startswith('rot_') and n.endswith('.json')for n in names),'board_static_template_models':3,'chalkboards':chalk},
            'validation':{'JSON_and_PNG_errors':validation_errors,'all_required_board_sources_present':all(r['texture_exists']and r['rotation_model_count']==16 and r['blockstate_exists']and r['item_model_exists']for r in boards),'all_light_textures_present':all(r['texture_exists']for r in lights)},
            'remaining_limits':['Extraction is not a Bedrock conversion.','No Minecraft/bridge/Blockbench runtime acceptance.','No real Bedrock Cookery package bound.','Uploaded NeoForge JAR is not the previously targeted Forge release archive.','Matching selected resources does not prove all assets or code match across versions.','Dynamic text and particle behavior remain porting tasks.']
        }
        write_json(reports/'jar-inventory.json',inventory)
        write_json(reports/'A16-vs-uploaded-JAR.json',{'summary':summary['comparison_to_A16'],'files':results})
        write_json(reports/'priority-family-inventory.json',{'lights':lights,'boards':boards,'chalkboard_disassembly':disassemblies})
        write_json(reports/'AUDIT.json',summary)
        write_json(output/'source-jar.lock.json',{'input':summary['input'],'asset_files':[r for r in inventory if r['path'] in extracted],'notes':['Exact member bytes retained; no PNG recompression or JSON reformatting.','Resources live separately under jar-resources; they do not overwrite the old Git-pinned upstream tree.']})
        return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--jar',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    print(json.dumps(run(args.jar,args.baseline,args.output),ensure_ascii=False,indent=2))
