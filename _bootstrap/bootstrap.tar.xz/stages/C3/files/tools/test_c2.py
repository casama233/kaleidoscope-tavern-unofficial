from test_c3 import main
if __name__=='__main__':raise SystemExit(main())
