# Tavern A17 — 原版 JAR 資源接入與差異核對

**本次缺失的彩燈、花草告示牌和大小黑板原件都找到了。這是來源接入包，不是 A17 基岩移植完成版。**

## 檢查的實際檔案

- 使用者上傳：`kaleidoscopetavern-1.2.0-neoforge+mc1.21.1.jar`
- 檔案大小：1,708,047 bytes。
- SHA-256：`03f35e1e614953b22cd1f5e34345613f3a6a283bf1b1c99659b57d58970edeff`。
- JAR 內 `MANIFEST.MF` 與 `neoforge.mods.toml` 均標示 1.2.0-neoforge+mc1.21.1。
- CRC 檢查通過；2,336 個壓縮檔項目，扣除目錄後為 2,085 個檔案；無重複 ZIP 路徑。
- 本次只讀取壓縮檔及使用 `javap` 檢查編譯後的類別，沒有執行模組或啟動 Minecraft。
- 來源標為 user_upload。未另向發布平台核驗整份 JAR 的官方雜湊，不能聲稱已認證發布來源或等同於先前 Forge 版。

## 優先缺口已確認

| 類別 | JAR 內取得的資源 | 尚須做的工作 |
|---|---|---|
| 彩燈 | 17 個獨立模型、17 張貼圖、17 個 blockstate；A16 所欠九款的 18 個模型／貼圖原件全部存在 | 轉換其餘九款幾何與材質，接入現有檢視器及測試 |
| 花草告示牌 | 13 種裝飾貼圖，加素面共 14 類；14 個物品模型及各類 blockstate；每類 16 方向上部模型 | 共用底座、雙材質與 quaternion 旋轉轉換，組合及方向驗收 |
| 告示牌整體 | 3 個主模板，240 個旋轉子模型（14 種上部×16＋共同底座×16），共243個 block model JSON | 不能把240個旋轉引用當成240種不同美術 |
| 小黑板 | `SmallChalkboardModel.class`、64×64原圖、物品圖示與相關定義 | 根據Java ModelPart轉出幾何，與原渲染座標对照 |
| 大黑板 | `LargeChalkboardModel.class`、128×64原圖與同一渲染器 | 同上；文字渲染屬另一項移植工作 |
| 粒子與其他後續資源 | 16個粒子定義、19張粒子PNG、物品模型、語言、音效等均已一次取出 | 有檔案不等於動態運動、液位、RGB或手持效果已移植 |

九款彩燈：green、light_blue、light_gray、lime、magenta、orange、pink、purple、yellow。

十三種裝飾告示牌：allium、azure_bluet、cornflower、grass、orchid、peony、pink_petals、pitcher_plant、poppy、sunflower、torchflower、tulip、wither_rose。

**`floral_board` 不是此包真正的資源目錄名稱；花草告示牌實際放在 `sandwich_board/<種類>/`。黑板的 `models/block/deco/chalkboard.json` 只提供粒子材質，沒有 `elements` 並不代表缺模型：其實體幾何在 Java 類別裡。**

## 與既有 A16 資源比較

基準檔案：`Tavern-Assets-A16.zip`，原固定提交 `6b0d619145316492f055e03d70427107cd73efa8`。

比對的是 A16 source lock 已收錄、能映射到 JAR `assets/` 的539份資源，不是整個版本的全部程式或所有資源。

| 結果 | 數量 |
|---|---:|
| 逐位元組相同 | 107 |
| 位元組不同，但 JSON 解析內容相同 | 377 |
| PNG 位元組不同，但尺寸與解碼後 RGBA 像素完全相同 | 55 |
| 缺檔或發現不同模型／像素內容 | 0 |

PNG總共比對155張：100張逐位元組相同，55張解碼後像素相同。這不保證PNG metadata、色彩管理或實際引擎渲染完全等效；也不把NeoForge／MC1.21.1誤標為Forge／MC1.20.1同一發布檔。

**原來的 A16 ZIP、Git-pinned來源、模型與貼圖均未覆寫。** 新來源獨立在`jar-resources/`，以JAR SHA-256及每個member的SHA-256另行鎖定。

## 已補查 GitHub

透過GitHub connector讀取`KaleidoscopeMods/KaleidoscopeTavern`的`1.21.1`分支，固定到：

`a1afba34981a00e89d57130d3dc8f1e64f1820a2`

取得並保存三份源碼：

- `SmallChalkboardModel.java`
- `LargeChalkboardModel.java`
- `ChalkboardBlockEntityRender.java`

三份文字檔均按GitHub返回的完整Git blob SHA-1核對；來源記錄見`github-source.lock.json`。

大小黑板模型的`createBodyLayer`參數已與此JAR的`javap`反組譯資料核對：

| 項目 | 小黑板 | 大黑板 |
|---|---|---|
| 原始 box 起點 | (-16,-30,15) | (-32,-30,15) |
| 原始 box 大小 | (16,28,1) | (48,28,1) |
| 骨架 offset | (8,24,-8) | (8,24,-8) |
| UV 起點 | (0,0) | (0,0) |
| 圖片尺寸 | 64×64 | 128×64 |

這是**幾何參數核對**，不是把當前分支提交冒認為此JAR的完整建置提交。渲染器源碼另保留作比對參考，其JAR反組譯也一併保存。

## 交付結構

```text
jar-resources/assets/kaleidoscope_tavern/  1295個美術及客戶端資源原件
jar-metadata/                            JAR內部版本資訊
source-jar.lock.json                      整份JAR及每個資源member的來源雜湊
github-source/                           三份完整黑板源碼參考
github-source.lock.json                  固定commit與Git blob驗證值
reports/AUDIT.json                       檢查總結
reports/A16-vs-uploaded-JAR.json           539份逐檔比較
reports/priority-family-inventory.json    彩燈、告示牌、黑板清單
reports/jar-inventory.json               原JAR所有2085個檔案的清單與雜湊
reports/javap/                           三份類別的唯讀反組譯
previews/source-textures.png             原始貼圖接觸表，不是轉換模型或遊戲畫面
tools/audit_jar.py                       可重跑的唯讀檢查／取件工具
```

1295個資源原件包含790個模型JSON、159個blockstate、305張PNG及其他動畫metadata、16個粒子JSON、4份語言、6個音效檔、4個ponder資源和sounds.json。模型數包括父模板、旋轉引用和物品模型，**不能當成790種獨立已移植美術**。

## 尚未完成

本包沒有新增Bedrock幾何、`.mcaddon`、玩法或實機驗收。Cookery仍需其真正的**基岩 `.mcaddon`／BP與RP manifest**，Tavern的Java JAR不能代替Cookery基岩依賴。

先前「本地缺源」只代表當時下載的子集缺件，不能再視為原版不存在。此次來源阻塞已解除，A17可使用這些有記錄的原件繼續轉換，不需要猜模型、重染貼圖或要求使用者手動湊18份檔案。

## 重跑

Python 3.10+、Pillow，以及提供`javap`的JDK。保留來源ZIP及JAR，對新的輸出目錄執行：

```text
python tools/audit_jar.py --jar "kaleidoscopetavern-1.2.0-neoforge+mc1.21.1.jar" --baseline "Tavern-Assets-A16.zip" --output "intake-recheck"
```

本工具不下載資料、不執行JAR，不修改原始ZIP/JAR。輸出目錄同名檔案會重寫，勿把`--output`指向手動修改的專案。

## 署名與授權

原作作者／團隊資訊依JAR metadata與既有LICENSE保留。原始美術歸Kaleidoscope原作者；`LICENSE-ASSETS`、`LICENSE-CODE`取自既有來源專案。解包、比較、縮圖排列不改變原作授權。不附字型檔、不附Cookery、不再附整份可執行JAR。本包不是上游官方基岩發布版。
